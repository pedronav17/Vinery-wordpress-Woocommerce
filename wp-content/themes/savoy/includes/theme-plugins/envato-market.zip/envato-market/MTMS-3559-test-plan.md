# MTMS-3559 Test Plan — PHP 8.4 Compatibility & v2.0.13 Release

## Environment Setup

```bash
docker compose pull && docker compose up -d
# Admin: http://localhost:8080/wp-admin  user: dev  pass: dev
# Tail log: docker compose exec wordpress tail -f /var/www/html/wp-content/debug.log
```

Activate the plugin: **Plugins → Installed Plugins → Envato Market → Activate**

---

## Test Cases

| # | Area | Steps | Expected | Pass |
|---|------|-------|----------|------|
| TC-01 | PHP deprecation notice | Activate plugin, check admin notice area | No "PHP below 8.2" deprecation banner (8.4 ≥ 8.2) | ☐ |
| TC-02 | Plugin activation | Deactivate → re-activate from Plugins list | Activates cleanly; Envato Market menu appears in sidebar; no errors in debug.log | ☐ |
| TC-03 | Admin tabs render | Open each tab: Settings / Themes / Plugins / Help | All tabs load; no white screen; Settings shows token field; Themes & Plugins show empty state | ☐ |
| TC-04a | Token auth — valid | Settings → enter valid token → Save Changes | Success notice; purchased themes & plugins listed; no PHP errors in log | ☐ |
| TC-04b | Token auth — invalid | Settings → enter random string → Save Changes | Error notice shown; no fatal errors in log | ☐ |
| TC-05 | Install theme | Themes tab → Install on any item → Activate | Installation completes; theme activates; no errors in log | ☐ |
| TC-06 | Install plugin | Plugins tab → Install on any item → Activate | Installation completes; plugin activates; no errors in log | ☐ |
| TC-07 | Update detection | Dashboard → Updates → Check Again (with ≥1 installed item) | Page loads; updates shown if available; no errors in log | ☐ |
| TC-08 | Health check | Help tab → Run Health Check | Results display; PHP shown as `8.4.x`; no JS console errors; no errors in log | ☐ |
| TC-09 | Deferred download / update | Themes or Plugins tab → trigger Update on installed item | Update completes; no `PHP Deprecated` or fatal errors in log | ☐ |
| TC-10 | Transient clearing | Settings → re-save settings | Transients clear; items re-fetched from API; no errors in log | ☐ |

**PHP 8.4 log check (applies to every TC):** `debug.log` must contain no `PHP Deprecated:`, `PHP Fatal error:`, or plugin-sourced `PHP Warning:` / `PHP Notice:` lines.

---

## Teardown

```bash
docker compose down
```

---

## Acceptance Criteria

| Criterion | Done |
|-----------|------|
| Docker environment running PHP 8.4 (`wordpress:6.7-php8.4-apache`) | ☐ |
| All TCs above pass with clean debug.log | ☐ |
| `docs/dist/update-check.json` at v2.0.13 / tested WP 6.7 | ☐ |
| `docs/dist/envato-market.zip` rebuilt via `grunt deploy` | ☐ |
| `v2.0.13` git tag and GitHub Release published | ☐ |
| https://www.envato.com/lp/market-plugin/ serves v2.0.13 | ☐ |
